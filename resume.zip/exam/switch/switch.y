%{
#include<stdio.h>
int yylex();
void yyerror(const char *s);
%}

%token SWITCH CASE BREAK DEFAULT ID NUM

%%

S : SWITCH '(' ID ')' '{'
    CASE NUM ':' BREAK ';'
    DEFAULT ':' BREAK ';'
    '}'
{
	printf("Valid Switch\n");
};

%%

void yyerror(const char *s)
{
	printf("Invalid\n");
}

int main()
{
	yyparse();
	return 0;
}