%{
#include<stdio.h>
int yylex();
void yyerror(const char *s);
%}

%token IF ELSE ID NUM RELOP

%%

S : IF '(' COND ')' '{' '}'
  | IF '(' COND ')' '{' '}' ELSE '{' '}'
{
	printf("Valid If Else\n");
};

COND : ID RELOP NUM ;

%%

void yyerror(const char *s)
{
	printf("Invalid\n");
}

int main()
{
	yyparse();
	return 0;
}