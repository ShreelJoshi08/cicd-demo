%{
#include<stdio.h>
int yylex();
void yyerror(const char *s);
%}

%token DT ID

%%

S : DT ID '(' ')' '{' '}'
{
	printf("Valid Function\n");
};

%%

void yyerror(const char *s)
{
	printf("Invalid\n");
}

int main()
{
	yyparse();
	return 0;
}