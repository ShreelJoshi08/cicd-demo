%{
#include<stdio.h>
int yylex();
void yyerror(const char *s);
%}

%token CLASS ID

%%

S : CLASS ID '{' '}' ';'
{
	printf("Valid Class\n");
};

%%

void yyerror(const char *s)
{
	printf("Invalid\n");
}

int main()
{
	yyparse();
	return 0;
}