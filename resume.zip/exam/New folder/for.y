%{
#include<stdio.h>
int yylex();
void yyerror(const char *s);
%}

%token FOR ID NUM RELOP INC

%%

S : FOR '(' ID '=' NUM ';' ID RELOP NUM ';' ID INC ')' '{' '}'
{
	printf("Valid For Loop\n");
};

%%

void yyerror(const char *s)
{
	printf("Invalid\n");
}

int main()
{
	yyparse();
	return 0;
}