%{
	#include<stdio.h>
	#include<stdlib.h>

	int yylex();
	void yyerror(const char *s);
%}

%token WHILE ID NUMBER RELOP

%%

S : WHILE '(' CONDITION ')' '{' '}'
	{
		printf("Valid While Loop\n");
	}
	;

CONDITION : ID RELOP NUMBER
	  | ID RELOP ID
	  ;

%%

void yyerror(const char *s)
{
	printf("Invalid While Loop\n");
}

int main()
{
	printf("Enter While Loop:\n");
	yyparse();
	return 0;
}