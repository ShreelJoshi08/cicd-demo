%{
#include<stdio.h>
int yylex();
void yyerror(const char *s);
%}

%token DO WHILE ID NUM RELOP

%%

S : DO '{' '}' WHILE '(' ID RELOP NUM ')' ';'
{
	printf("Valid Do While\n");
};

%%

void yyerror(const char *s)
{
	printf("Invalid\n");
}

int main()
{
	yyparse();
	return 0;
}