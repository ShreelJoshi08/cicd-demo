%{
#include<stdio.h>
int yylex();
void yyerror(const char *s);
%}

%token DT ID NUM

%%

S : DT ID ';'
  | DT ID '=' NUM ';'
{
	printf("Valid Variable Declaration\n");
};

%%

void yyerror(const char *s)
{
	printf("Invalid\n");
}

int main()
{
	yyparse();
	return 0;
}